create definer = root@localhost view hoadonsp as
select `o`.`orderId`                   AS `orderId`,
       `o`.`productId`                 AS `productId`,
       `o`.`quantity`                  AS `quantity`,
       `demo2006`.`order`.`customerId` AS `customerId`,
       `demo2006`.`order`.`time`       AS `time`
from (`demo2006`.`order` join `demo2006`.`orderdetail` `o` on ((`demo2006`.`order`.`id` = `o`.`orderId`)));

